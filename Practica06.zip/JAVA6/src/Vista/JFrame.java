package Vista;

import Controlador.*;
import Modelo.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JFrame extends javax.swing.JFrame{
    
    Cliente cli;
    
    public static JFrame recargar;
            
    public JFrame() {
        initComponents();
        btnVisual.setEnabled(false);
        btnGestion.setEnabled(false);
        btnAcerca.setEnabled(false);
        ocultarBotones();
    }
    
    public void ocultarBotones(){
        txfUsuario.setVisible(false);
        txfContrasenia.setVisible(false);
        labContrasenia.setVisible(false);
        labUsuario.setVisible(false);
        btnAceptar.setVisible(false);
    }
    
    public void actualizarPanel(javax.swing.JPanel panel){
        this.setContentPane(panel);
        pack();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        labTitulo = new javax.swing.JLabel();
        labUsuario = new javax.swing.JLabel();
        labContrasenia = new javax.swing.JLabel();
        btnAceptar = new javax.swing.JToggleButton();
        txfContrasenia = new javax.swing.JTextField();
        txfUsuario = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        btnAbrir = new javax.swing.JMenuItem();
        btnCerrar = new javax.swing.JMenuItem();
        btnVisual = new javax.swing.JMenu();
        btnPerfil = new javax.swing.JMenuItem();
        btnPedidos = new javax.swing.JMenuItem();
        btnInstalaciones = new javax.swing.JMenuItem();
        btnGestion = new javax.swing.JMenu();
        btnPedido = new javax.swing.JMenuItem();
        btnBajaPed = new javax.swing.JMenuItem();
        btnAcerca = new javax.swing.JMenu();

        jMenuItem1.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        labTitulo.setFont(new java.awt.Font("Liberation Mono", 0, 48)); // NOI18N
        labTitulo.setText("PRACTICA 6");

        labUsuario.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labUsuario.setText("Usuario");

        labContrasenia.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        labContrasenia.setText("Contraseña");

        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(331, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(labTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labUsuario)
                            .addComponent(labContrasenia))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txfUsuario)
                            .addComponent(txfContrasenia, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(323, 323, 323))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addComponent(labTitulo)
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labUsuario)
                    .addComponent(txfUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labContrasenia)
                    .addComponent(txfContrasenia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnAceptar)
                .addContainerGap(189, Short.MAX_VALUE))
        );

        jMenu1.setText("Conexión");

        btnAbrir.setText("Abrir");
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });
        jMenu1.add(btnAbrir);

        btnCerrar.setText("Cerrar");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });
        jMenu1.add(btnCerrar);

        jMenuBar1.add(jMenu1);

        btnVisual.setText("Visualizar");

        btnPerfil.setText("Perfil");
        btnPerfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPerfilActionPerformed(evt);
            }
        });
        btnVisual.add(btnPerfil);

        btnPedidos.setText("Pedidos");
        btnPedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPedidosActionPerformed(evt);
            }
        });
        btnVisual.add(btnPedidos);

        btnInstalaciones.setText("Instalaciones");
        btnInstalaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInstalacionesActionPerformed(evt);
            }
        });
        btnVisual.add(btnInstalaciones);

        jMenuBar1.add(btnVisual);

        btnGestion.setText("Gestión");

        btnPedido.setText("Alta Pedido");
        btnPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPedidoActionPerformed(evt);
            }
        });
        btnGestion.add(btnPedido);

        btnBajaPed.setText("Baja Pedido");
        btnBajaPed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBajaPedActionPerformed(evt);
            }
        });
        btnGestion.add(btnBajaPed);

        jMenuBar1.add(btnGestion);

        btnAcerca.setText("Acerca De");
        btnAcerca.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAcercaMouseClicked(evt);
            }
        });
        jMenuBar1.add(btnAcerca);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        txfUsuario.setVisible(true);
        txfContrasenia.setVisible(true);
        labContrasenia.setVisible(true);
        labUsuario.setVisible(true);
        btnAceptar.setVisible(true);
        txfUsuario.setText("rep");
        txfContrasenia.setText("rep");
        Conexion.open();
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        this.setVisible(true);
        labTitulo.setVisible(true);
        Conexion.close();
        dispose();
        JFrame frame = new JFrame();
        frame.setVisible(true);
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void btnPerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPerfilActionPerformed
        try {
            VisualPerfil perfil = new VisualPerfil(cli);
            actualizarPanel(perfil);
        } catch (GestionErroresUsuario ex) {
            Logger.getLogger(JFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnPerfilActionPerformed

    private void btnPedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPedidosActionPerformed
        try {
            VisualPedidos pedidos = new VisualPedidos(cli);
            actualizarPanel(pedidos);
        } catch (GestionErroresUsuario ex) {
            Logger.getLogger(JFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnPedidosActionPerformed

    private void btnInstalacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInstalacionesActionPerformed
        try {
            Visualinstalacion insta = new Visualinstalacion(cli);
            actualizarPanel(insta);
        } catch (GestionErroresUsuario ex) {
            Logger.getLogger(JFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnInstalacionesActionPerformed

    private void btnPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPedidoActionPerformed
        try {
            VisualAltas alta = new VisualAltas(cli);
            actualizarPanel(alta);
        } catch (GestionErroresUsuario ex) {
            Logger.getLogger(JFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnPedidoActionPerformed

    private void btnBajaPedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBajaPedActionPerformed
        try {
            VisualBajas baja = new VisualBajas(cli);
            actualizarPanel(baja);
        } catch (GestionErroresUsuario ex) {
            Logger.getLogger(JFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnBajaPedActionPerformed

    private void btnAcercaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAcercaMouseClicked
        VisualAcercaDe info = new VisualAcercaDe(this,true);
        info.setVisible(true);
    }//GEN-LAST:event_btnAcercaMouseClicked

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
        String usuario = txfUsuario.getText();
        String contrasenia = txfContrasenia.getText();
        
        try{
            cli = ClienteBD.getCliente(usuario, contrasenia);
        }catch(GestionErroresUsuario e){
            e.lanzarError();
        }
        
        if(cli != null){
            ocultarBotones();
            btnVisual.setEnabled(true);
            btnGestion.setEnabled(true);
            btnAcerca.setEnabled(true);
        }
    }//GEN-LAST:event_btnAceptarActionPerformed
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                JFrame.recargar = new JFrame();
                recargar.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem btnAbrir;
    private javax.swing.JToggleButton btnAceptar;
    private javax.swing.JMenu btnAcerca;
    private javax.swing.JMenuItem btnBajaPed;
    private javax.swing.JMenuItem btnCerrar;
    private javax.swing.JMenu btnGestion;
    private javax.swing.JMenuItem btnInstalaciones;
    private javax.swing.JMenuItem btnPedido;
    private javax.swing.JMenuItem btnPedidos;
    private javax.swing.JMenuItem btnPerfil;
    private javax.swing.JMenu btnVisual;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labContrasenia;
    private javax.swing.JLabel labTitulo;
    private javax.swing.JLabel labUsuario;
    private javax.swing.JTextField txfContrasenia;
    private javax.swing.JTextField txfUsuario;
    // End of variables declaration//GEN-END:variables
}
