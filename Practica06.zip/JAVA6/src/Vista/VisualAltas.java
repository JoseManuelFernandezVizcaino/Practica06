
package Vista;

import Controlador.*;
import Modelo.*;
import java.awt.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class VisualAltas extends javax.swing.JPanel {
    
    Cliente cliente;
    Maquina maquinaAux;
    int idVenta = numeroAleatorio();
    
    public VisualAltas(Cliente cli) throws GestionErroresUsuario {
        initComponents();

        cliente = cli;
        txtID.setEnabled(false);
        txtID.setBackground(Color.GRAY);
        txtID.setText("Autonumerico");
        Image img= new ImageIcon(cli.getImagen()).getImage();
        ImageIcon img2=new ImageIcon(img.getScaledInstance(273, 219, Image.SCALE_SMOOTH));
        imagen.setIcon(img2);
        insertarDatosComboBox();
    }
    
    public void insertarDatosComboBox() throws GestionErroresUsuario{
        ArrayList<Maquina> lista;
        lista = MaquinaBD.getMaquinas();
        
        for(Maquina maquinaAux : lista) {
            txtmaquinas.addItem(maquinaAux.getModelo());  
        }
    }
    
    public void altaMaquina(String modelo) throws GestionErroresUsuario{
        Maquina maquinaA;
        maquinaA = MaquinaBD.getMaquina(modelo);
        int num = numeroAleatorio();
        MaquinaBD.setMaquina(maquinaA,idVenta,num);;
        maquinaA = MaquinaBD.getMaquina(modelo,num);
        altaInstalacion(maquinaA);
    }
        
    public int numeroAleatorio(){
        int numero =  (int)Math.floor(Math.random()*(1000));
        return numero;
    }
    
    public void altaInstalacion(Maquina maquina) throws GestionErroresUsuario{
        String dni = recogerDni();
        String pais = txtPais.getText();
        String id = Integer.toString(numeroAleatorio())+generarLetra();
        InstalacionBD.setInstalacion(id,pais,maquina.getIdMaquina(),dni);        
    }
    
    public String recogerDni() throws GestionErroresUsuario{
        ArrayList<Montador> lista;
        lista = MontadorBD.getMontadores();
        int numero =  (int)Math.floor(Math.random()*(lista.size()));
        String dni = lista.get(numero).getDni();
        return dni;
    }
    
    public char generarLetra(){
        Random random = new Random();
        char randomLetra= (char) (random.nextInt(26) + 'A');
        
        return randomLetra;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        txtID = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtTipo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtEstado = new javax.swing.JTextField();
        txtGestion = new javax.swing.JTextField();
        imagen = new javax.swing.JLabel();
        btnAceptar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        txtmaquinas = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        txtPais = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();

        jLabel5.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        jLabel5.setText("PEDIDO");

        jLabel1.setText("ID Venta");

        jLabel2.setText("Tipo");

        jLabel3.setText("Gestion");

        jLabel4.setText("Estado");

        imagen.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        txtmaquinas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Elige una maquina" }));

        jLabel6.setText("MAQUINA");

        jLabel7.setText("Pais");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(67, 67, 67)
                        .addComponent(txtmaquinas, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(57, 57, 57))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(74, 74, 74)
                                .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtPais)
                                    .addComponent(txtGestion)
                                    .addComponent(txtEstado, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtTipo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(96, 96, 96))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 150, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)
                        .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(176, 176, 176))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(411, 411, 411))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtGestion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txtEstado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(imagen, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPais, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 80, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtmaquinas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(btnAceptar))
                .addGap(44, 44, 44))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
        try {
            String estadoPedido = txtEstado.getText();
            String nombreGestion = txtGestion.getText();
            String tipoDeDato = txtTipo.getText();
            
            PedidoBD.setPedido(idVenta,tipoDeDato,nombreGestion,estadoPedido,cliente.getIdCliente());
            String modelo = (String)txtmaquinas.getSelectedItem();
            altaMaquina(modelo);
            VisualAltas visual = new VisualAltas(cliente);
            JFrame.recargar.actualizarPanel(visual);
        } catch (GestionErroresUsuario ex) {
            ex.lanzarError();            
        }

    }//GEN-LAST:event_btnAceptarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAceptar;
    private javax.swing.JLabel imagen;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JTextField txtEstado;
    private javax.swing.JTextField txtGestion;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtPais;
    private javax.swing.JTextField txtTipo;
    private javax.swing.JComboBox<String> txtmaquinas;
    // End of variables declaration//GEN-END:variables
}
