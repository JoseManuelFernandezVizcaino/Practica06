package Modelo;

import java.util.*;

public class Instalacion {
    
    private String idInstalacion;
    private GregorianCalendar fechaInstalacion;
    private String pais;
    private int idMaquina;
    private String dni;
    
    public Instalacion(){
        
    }
    
    public Instalacion(String idInstalacion, GregorianCalendar fechaInstalacion, String pais, int idMaquina, String dni){
        this.idInstalacion = idInstalacion;
        this.fechaInstalacion = fechaInstalacion;
        this.pais = pais;
        this.idMaquina = idMaquina;
        this.dni = dni;
    }
    
    public String getIdInstalacion() {
        return idInstalacion;
    }

    public void setIdInstalacion(String idInstalacion) {
        this.idInstalacion = idInstalacion;
    }

    public GregorianCalendar getFechaInstalacion() {
        return fechaInstalacion;
    }

    public void setFechaInstalacion(GregorianCalendar fechaInstalacion) {
        this.fechaInstalacion = fechaInstalacion;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getIdMaquina() {
        return idMaquina;
    }

    public void setIdMaquina(int idMaquina) {
        this.idMaquina = idMaquina;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Instalacion{" + "idInstalacion=" + idInstalacion + ", fechaInstalacion=" + fechaInstalacion + ", pais=" + pais + ", idMaquina=" + idMaquina + ", dni=" + dni + '}';
    }
    
    
}
