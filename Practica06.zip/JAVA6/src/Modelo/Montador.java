package Modelo;

public class Montador {
    
    private String dni;
    private String nombre;
    private String apellido;
    private String especialidad;
    private String pais;
    private String ciudad;
    private String direccion;
    
    public Montador(){
        
    }
    
    public Montador(String dni, String nombre, String apellido, String especialidad, String pais, String ciudad, String direccion){
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.especialidad = especialidad;
        this.pais = pais;
        this.ciudad = ciudad;
        this.direccion = direccion;                
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Montador{" + "dni=" + dni + ", nombre=" + nombre + ", apellido=" + apellido + ", especialidad=" + especialidad + ", pais=" + pais + ", ciudad=" + ciudad + ", direccion=" + direccion + '}';
    }
    
    
}
