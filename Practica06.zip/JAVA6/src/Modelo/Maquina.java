package Modelo;

import Controlador.*;
import java.util.*;

public class Maquina {
    
    private int idMaquina;
    private String modelo;
    private int precio;
    private String tamanio;
    private GregorianCalendar fechaProduccion;
    private int costeProduccion;
    private int idClienteMaquina;
    
    public Maquina(){
        
    }
    
    public Maquina(int idMaquina, String modelo, int precio, String tamanio, GregorianCalendar fechaProduccion, int costeProduccion, int idClienteMaquina){
        this.idMaquina = idMaquina;
        this.modelo = modelo;
        this.precio = precio;
        this.tamanio = tamanio;
        this.fechaProduccion = fechaProduccion;
        this.costeProduccion = costeProduccion;
        this.idClienteMaquina = idClienteMaquina;
    }

    public int getIdMaquina() {
        return idMaquina;
    }

    public void setIdMaquina(int idMaquina) {
        this.idMaquina = idMaquina;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getTamanio() {
        return tamanio;
    }

    public void setTamanio(String tamanio) {
        this.tamanio = tamanio;
    }

    public GregorianCalendar getFechaProduccion() {
        return fechaProduccion;
    }

    public void setFechaProduccion(GregorianCalendar fechaProduccion) {
        this.fechaProduccion = fechaProduccion;
    }

    public int getCosteProduccion() {
        return costeProduccion;
    }

    public void setCosteProduccion(int costeProduccion) {
        this.costeProduccion = costeProduccion;
    }

    public int getIdClienteMaquina() {
        return idClienteMaquina;
    }

    public void setIdClienteMaquina(int idClienteMaquina) {
        this.idClienteMaquina = idClienteMaquina;
    }

    @Override
    public String toString() {
        return "Maquina{" +idMaquina + ", modelo=" + modelo + ", precio=" + precio + ", tamaño=" + tamanio + ", fechaProduccion=" + Herramienta.gregorianCalendarToString(fechaProduccion) + ", costeProduccion=" + costeProduccion + '}';
    }
    
    public String toStringDatos() {
        return  modelo + "," + precio + "," + tamanio;
    }
}
