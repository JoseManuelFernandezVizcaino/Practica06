package Modelo;

public class PedidoVenta {
    
    private int idVenta;
    private String tipoDeDato;
    private String nombreGestion;
    private String estadoPedido;
    private int idCliente;
    
    public PedidoVenta(){
        
    }
    
    public PedidoVenta(int idVenta, String tipoDeDato, String nombreGestion, String estadoPedido, int idCliente){
        this.idVenta = idVenta;
        this.tipoDeDato = tipoDeDato;
        this.nombreGestion = nombreGestion;
        this.estadoPedido = estadoPedido;
        this.idCliente = idCliente;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getTipoDeDato() {
        return tipoDeDato;
    }

    public void setTipoDeDato(String tipoDeDato) {
        this.tipoDeDato = tipoDeDato;
    }

    public String getNombreGestion() {
        return nombreGestion;
    }

    public void setNombreGestion(String nombreGestion) {
        this.nombreGestion = nombreGestion;
    }

    public String getEstadoPedido() {
        return estadoPedido;
    }

    public void setEstadoPedido(String estadoPedido) {
        this.estadoPedido = estadoPedido;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    @Override
    public String toString() {
        return "PedidoVenta{" + "idVenta=" + idVenta + ", tipoDeDato=" + tipoDeDato + ", nombreGestion=" + nombreGestion + ", estadoPedido=" + estadoPedido + ", idCliente=" + idCliente + '}';
    }
    
    
}
