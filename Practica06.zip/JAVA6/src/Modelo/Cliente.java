package Modelo;

import java.util.*;

public class Cliente {
    
    private static String rutaImagenes = "imagenes/";
    private int idCliente;
    private int cuentaCliente;
    private String nombre;
    private int telefono;
    private String ciudad;
    private String pais;
    private String direccion;
    private String usuario;
    private String contrasenia;
    private String dni;
    private String imagen;
    private float gastos;
    private int numeroPedidos;
    private GregorianCalendar fecha;
    
    public Cliente(){
        
    }

    public Cliente(int idCliente, int cuentaCliente, String nombre, int telefono, String ciudad, String pais, 
            String direccion, String usuario, String contrasenia, String dni, String imagen, GregorianCalendar fecha) {
        
        this.idCliente = idCliente;
        this.cuentaCliente = cuentaCliente;
        this.nombre = nombre;
        this.telefono = telefono;
        this.ciudad = ciudad;
        this.pais = pais;
        this.direccion = direccion;
        this.usuario = usuario;
        this.contrasenia = contrasenia;
        this.dni = dni;
        this.imagen = imagen;
        this.gastos = gastos;
        this.numeroPedidos = numeroPedidos;
        this.fecha = fecha;
    }
    
    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public int getCuentaCliente() {
        return cuentaCliente;
    }

    public void setCuentaCliente(int cuentaCliente) {
        this.cuentaCliente = cuentaCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getImagen() {
        String cadena = rutaImagenes+imagen;
        return cadena;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public int getNumeroPedidos() {
        return numeroPedidos;
    }

    public void setNumeroPedidos(int numeroPedidos) {
        this.numeroPedidos += numeroPedidos;
    }

    public float getGastos() {
        return gastos;
    }

    public void setGastos(float gastos) {
        this.gastos += gastos;
    }

    public GregorianCalendar getFecha() {
        return fecha;
    }

    public void setFecha(GregorianCalendar fecha) {
        this.fecha = fecha;
    }
    
    
}
