package Controlador;

import Modelo.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;

public class ClienteBD {
    
    private static Connection con = null;
    private static Statement st = null;
    private static PreparedStatement ps = null;
    private static ResultSet rs = null;
        
    public static Cliente getCliente(String usuario, String contrasenia) throws GestionErroresUsuario{
        try{
            con = Conexion.getConnection();
            String query = "SELECT * FROM CLIENTE WHERE USUARIO = ? AND CONTRASENIA = ?";
            ps = con.prepareStatement(query);
            
            ps.setString(1, usuario);
            ps.setString(2, contrasenia);
            
            rs = ps.executeQuery();
            rs.next();
            
            Cliente auxCli = new Cliente(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getInt(4),rs.getString(5),
                                        rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),
                                        rs.getString(11),Herramienta.dateToGregorianCalendar(rs.getDate(14)));
            
            JOptionPane.showMessageDialog(null, "Login correcto");

            rs.close();
            ps.close();
            return auxCli;
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(3);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
    }
    
    public static void actualizarImagen(String img,int id) throws GestionErroresUsuario{
        try{
                        
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate("UPDATE CLIENTE SET IMAGEN = '"+img+"' WHERE ID_CLIENTE = " +id);
            st.close();
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }
    
    }
    
    public static void actualizarCliente (GregorianCalendar fecha,String dni) throws GestionErroresUsuario{
        try{       
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            if(fecha == null){
                st.executeUpdate("UPDATE CLIENTE SET DNI = '"+dni+"'");
            }else{
                st.executeUpdate("UPDATE CLIENTE SET FECHA_REGISTRO = '"+fecha.get(Calendar.YEAR)+"-"+(fecha.get(Calendar.MONTH)+1) +"-"+fecha.get(Calendar.DAY_OF_MONTH)+"', DNI = '"+dni+"'");
            }
            
            st.close();
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }
        JOptionPane.showMessageDialog(null,"Se han guardado los datos correctamente");
    }
    
}