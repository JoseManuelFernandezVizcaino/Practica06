package Controlador;

import Modelo.*;
import java.sql.*;
import java.util.*;

public class InstalacionBD {
    
    private static Statement st = null;
    private static ResultSet rs = null;
    
    public static Instalacion getInstalacion(int id) throws GestionErroresUsuario{
        
        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery("SELECT * FROM INSTALACION WHERE ID_MAQUINA = " +id);
            rs.next();
            
            Instalacion auxIns = new Instalacion(rs.getString(1),Herramienta.dateToGregorianCalendar(rs.getDate(2)),rs.getString(3),rs.getInt(4),rs.getString(5));
            
            return auxIns;
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        

    }
    
    public static void setInstalacion(String id, String pais, int idMaquina, String dni) throws GestionErroresUsuario{
        GregorianCalendar fecha = new GregorianCalendar();
        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate("INSERT INTO INSTALACION VALUES('"+id+"','"+fecha.get(Calendar.YEAR)+"-"+(fecha.get(Calendar.MONTH)+1) +"-"+fecha.get(Calendar.DAY_OF_MONTH)+"','"+pais+"',"+idMaquina+",'"+dni+"')");
            st.close();
  
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
       
    }
    
    public static void deleteInstalacion(int idVenta) throws GestionErroresUsuario{

        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate("DELETE FROM INSTALACION WHERE ID_MAQUINA = (SELECT ID_MAQUINA FROM MAQUINA WHERE ID_CLIENTE_MAQUINA ="+idVenta+")" );
            st.close();
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
       
    }
    
    public static Instalacion getSiguiente(){
        try{
            if(rs.next()){
                
                Instalacion auxIns = new Instalacion(rs.getString(1),Herramienta.dateToGregorianCalendar(rs.getDate(2)),rs.getString(3),rs.getInt(4),rs.getString(5));

                return auxIns;
           }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public static Instalacion getAnterior(){
        
        try{
            if(rs.previous()){
                
                Instalacion auxIns = new Instalacion(rs.getString(1),Herramienta.dateToGregorianCalendar(rs.getDate(2)),rs.getString(3),rs.getInt(4),rs.getString(5));

                return auxIns;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public static boolean getPrimero(){
        try{
            if(rs.first()){
                return rs.first();
           }

        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
        
    public static void cerrar(){
        try{
            rs.close();
            st.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
