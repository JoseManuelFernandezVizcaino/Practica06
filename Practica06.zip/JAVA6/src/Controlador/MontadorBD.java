package Controlador;

import Modelo.*;
import java.sql.*;
import java.util.*;

public class MontadorBD {
    
    private static Statement st = null;
    private static ResultSet rs = null;
    
    public static ArrayList getMontadores(String dni) throws GestionErroresUsuario{

        ArrayList<Montador> lista = new ArrayList<Montador>();
        
        try{
            st = Conexion.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM MONTADOR WHERE DNI = '" + dni +"'");
            
            while(rs.next()){
                Montador auxMon = new Montador(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
                        rs.getString(5),rs.getString(6),rs.getString(7));

                lista.add(auxMon);
            }
            rs.close();
            st.close();
            
            
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
        
        return lista;
    }
    
    public static ArrayList getMontadores() throws GestionErroresUsuario{

        ArrayList<Montador> lista = new ArrayList<Montador>();
        
        try{
            st = Conexion.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM MONTADOR");
            
            while(rs.next()){
                Montador auxMon = new Montador(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),
                        rs.getString(5),rs.getString(6),rs.getString(7));

                lista.add(auxMon);
            }
            rs.close();
            st.close();
            
            
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
        
        return lista;
    }
}
