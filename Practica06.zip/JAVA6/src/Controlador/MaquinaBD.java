
package Controlador;

import Modelo.*;
import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.swing.*;

public class MaquinaBD {
    
    private static Statement st = null;
    private static ResultSet rs = null;
    private static int cont = 0;
    
    public static ArrayList getMaquinas()throws GestionErroresUsuario{
        
        ArrayList<Maquina> lista = new ArrayList<Maquina>();
        
        try{
            st = Conexion.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM MAQUINA");
  
            while(rs.next()){
                Maquina auxMaq = new Maquina(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),
                        Herramienta.dateToGregorianCalendar(rs.getDate(5)),rs.getInt(6),rs.getInt(7));

                lista.add(auxMaq);
                
            }
            rs.close();
            st.close();
            
            
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
        return lista;
    }
        
    public static ArrayList getMaquinas(int id)throws GestionErroresUsuario{
        
        ArrayList<Maquina> lista = new ArrayList<Maquina>();
        
        try{
            st = Conexion.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM MAQUINA WHERE ID_CLIENTE_MAQUINA = " + id );
            
            while(rs.next()){
                Maquina auxMaq = new Maquina(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),
                        Herramienta.dateToGregorianCalendar(rs.getDate(5)),rs.getInt(6),rs.getInt(7));

                lista.add(auxMaq);
            }
            rs.close();
            st.close();
            
            
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
        
        return lista;
    }
    
    public static Maquina getMaquina(int id)throws GestionErroresUsuario{
        
        try{
            st = Conexion.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM MAQUINA WHERE ID_CLIENTE_MAQUINA = " + id );
            rs.next();
            
            Maquina auxMaq = new Maquina(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),
                        Herramienta.dateToGregorianCalendar(rs.getDate(5)),rs.getInt(6),rs.getInt(7));

            rs.close();
            st.close();
            
            return auxMaq;
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
        
    }
        
    public static void setMaquina(Maquina maquina, int id, int num) throws GestionErroresUsuario{
        GregorianCalendar fecha = new GregorianCalendar();
        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate("INSERT INTO MAQUINA VALUES ("+num+",'"+maquina.getModelo()+"',"+ maquina.getPrecio()+",'"
            +maquina.getTamanio()+"','"+fecha.get(Calendar.YEAR)+"-"+(fecha.get(Calendar.MONTH)+1) +"-"+fecha.get(Calendar.DAY_OF_MONTH)+"',"+maquina.getCosteProduccion()+","+id+")");
            st.close();
     
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
       
    }
    
    public static void deleteMaquina(String idVenta) throws GestionErroresUsuario{

        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate("DELETE FROM MAQUINA WHERE ID_CLIENTE_MAQUINA= " +idVenta);
            st.close();
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
       
    }
    
    public static Maquina getMaquina(String modelo) throws GestionErroresUsuario{
        
        try{
            st = Conexion.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM MAQUINA WHERE MODELO = '" + modelo +"'");
            rs.next();
            
            Maquina auxMaq = new Maquina(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),
                        Herramienta.dateToGregorianCalendar(rs.getDate(5)),rs.getInt(6),rs.getInt(7));

            rs.close();
            st.close();
            
            return auxMaq;
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        

    }
    
        public static Maquina getMaquina(String modelo,int num) throws GestionErroresUsuario{
        
        try{
            st = Conexion.getConnection().createStatement();
            rs = st.executeQuery("SELECT * FROM MAQUINA WHERE MODELO = '" + modelo +"' AND ID_MAQUINA = "+num);
            rs.next();
            
            Maquina auxMaq = new Maquina(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),
                        Herramienta.dateToGregorianCalendar(rs.getDate(5)),rs.getInt(6),rs.getInt(7));

            rs.close();
            st.close();
            
            return auxMaq;
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        

    }
}
