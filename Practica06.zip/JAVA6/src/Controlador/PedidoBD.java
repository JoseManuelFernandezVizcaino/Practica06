package Controlador;

import Modelo.*;
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class PedidoBD {
    
    private static Statement st = null;
    private static ResultSet rs = null;
    
    public static PedidoVenta getPedido(int id) throws GestionErroresUsuario{
        
        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            rs = st.executeQuery("SELECT * FROM PEDIDO_VENTA WHERE ID_CLIENTE = " + id );
            rs.next();
            
            PedidoVenta auxPedi = new PedidoVenta(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
            
            return auxPedi;
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
    }
    
    public static void setPedido(int idVenta, String tipoDeDato, String nombreGestion, String estadoPedido, int idCliente) throws GestionErroresUsuario{

        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate("INSERT INTO PEDIDO_VENTA VALUES("+idVenta+",'"+tipoDeDato+"','"+nombreGestion+"','"+estadoPedido+"',"+idCliente+")");
            st.close();
            JOptionPane.showMessageDialog(null, "Alta realizada");
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
       
    }
    
    public static void deletePedido(String idVenta) throws GestionErroresUsuario{

        try{
            st = Conexion.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,  ResultSet.CONCUR_READ_ONLY);
            st.executeUpdate("DELETE FROM PEDIDO_VENTA WHERE ID_VENTA = " +idVenta);
            st.close();
            Component parentComponent = null;
            JOptionPane.showMessageDialog(parentComponent, "Baja realizada");
        }catch(SQLException e){
            GestionErroresUsuario err = new GestionErroresUsuario(4);
            GestionErroresUsuario.guardarError(e.getMessage());
            throw err;
        }        
       
    }
        
    public static PedidoVenta getSiguiente(){
        try{
            if(rs.next()){
                
                PedidoVenta auxPedi = new PedidoVenta(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
               
                return auxPedi;
           }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public static PedidoVenta getAnterior(){
        
        try{
            if(rs.previous()){
                
                PedidoVenta auxPedi = new PedidoVenta(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));

                return auxPedi;
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public static PedidoVenta getPrimero(){
        try{
            if(rs.first()){
                PedidoVenta auxPedi = new PedidoVenta(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));
                return auxPedi;
           }

        }catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }
    
    public static boolean getUltimo(){
        try{
            if(rs.last() == true){
                rs.previous();
                return true;
           }

        }catch(Exception e){
            e.printStackTrace();
        }
        
        return false;
    }
        
    public static void cerrar(){
        try{
            rs.close();
            st.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public static ResultSet getResult(){
        return rs;
    }
}
