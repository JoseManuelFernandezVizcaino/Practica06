package Controlador;

import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

public class Herramienta { 
  
    public static String gregorianCalendarToString(GregorianCalendar fecha){         
        SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
        return formatDate.format(fecha.getTime());        
    }    
    
    public static GregorianCalendar dateToGregorianCalendar(Date fecha){
        GregorianCalendar gc = new GregorianCalendar();
        gc.setTime(fecha);
        return gc;
    }
    
    public static void mensaje(String mensaje){
        
        JOptionPane.showMessageDialog(null, mensaje);
    }
    
}
