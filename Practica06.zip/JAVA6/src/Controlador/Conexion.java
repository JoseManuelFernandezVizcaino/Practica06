package Controlador;

import java.sql.*;

public class Conexion {
    
    private static Connection con = null;

    public static void open() {
        try {
            Class.forName("com.mysql.jdbc.Driver");	
        } catch (ClassNotFoundException e) {
            GestionErroresUsuario err = new GestionErroresUsuario(1);
            err.lanzarError();
        }
               
        String url = "jdbc:mysql://localhost:3306/practica";
        try {
            con = DriverManager.getConnection(url,"root","1234");
        } catch (SQLException ex) {
            GestionErroresUsuario err = new GestionErroresUsuario(2);
            err.lanzarError();
        }
        
    }

    public static Connection getConnection() throws SQLException {
        return con;
    } 
    
    public static void close() {
        try {
            con.close();
        } catch (Exception ignored) {}
    } 
}
