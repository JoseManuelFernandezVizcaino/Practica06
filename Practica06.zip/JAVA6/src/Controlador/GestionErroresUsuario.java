package Controlador;

import java.io.*;
import java.text.*;
import java.util.*;

public class GestionErroresUsuario extends Exception{
    
    private String mensaje;
    private int codigo;
    
    public GestionErroresUsuario(int codigo){
        
        this.codigo = codigo;
        
        switch(codigo){
            case 1: this.mensaje = "Error al cargar los drivers";
                    break;
            case 2: this.mensaje = "No se ha podido establecer la conexion con la base de datos.";
                    break;
            case 3: this.mensaje = "Credenciales invalidas";
                    break;
            case 4: this.mensaje = "Error SQL";
                    break;
            case 5: this.mensaje = "DNI invalido";
                    break;
            case 6: this.mensaje = "No has seleccionado ningun archivo";
                    break;
            default: this.mensaje = "Error deconocido";
                    break;
        }
        
    }
    
    public void lanzarError(){
        
        SimpleDateFormat date = new SimpleDateFormat("dd/MM/yyyy  (HH:mm:ss)");
        GregorianCalendar gc = new GregorianCalendar();
        
        String lineaError = date.format(gc.getTime())+"\nNº de Error:"+codigo+"\nMensaje:"+mensaje;
        
        Herramienta.mensaje(lineaError);
    }
    
    public static void guardarError(String error){
        
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File("./log"),true));
            
            bw.write(error);
            bw.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
